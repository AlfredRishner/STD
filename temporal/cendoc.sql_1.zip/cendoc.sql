-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 12-08-2016 a las 18:53:00
-- Versión del servidor: 5.7.14
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `cendoc`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `documentos`
-- 

CREATE TABLE `documentos` (
  `iddocumentos` int(11) NOT NULL AUTO_INCREMENT,
  `idtipo` int(11) NOT NULL,
  `idproyecto` int(11) NOT NULL,
  `numero` varchar(45) DEFAULT NULL,
  `asunto` varchar(45) DEFAULT NULL,
  `fecha` varchar(45) DEFAULT NULL,
  `para` varchar(45) DEFAULT NULL,
  `de` varchar(45) DEFAULT NULL,
  `archivo` varchar(45) DEFAULT NULL,
  `documentoscol` varchar(45) DEFAULT NULL,
  `folios` varchar(45) DEFAULT NULL,
  `codigo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`iddocumentos`),
  KEY `fk_idtipo` (`idtipo`),
  KEY `fk_idproyecto` (`idproyecto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `documentos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `proyecto`
-- 

CREATE TABLE `proyecto` (
  `idproyecto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `lat` varchar(45) DEFAULT NULL,
  `long` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `link` varchar(45) DEFAULT NULL,
  `proyectocol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idproyecto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `proyecto`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipo`
-- 

CREATE TABLE `tipo` (
  `idtipo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tipo`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paterno` varchar(45) DEFAULT NULL,
  `materno` varchar(45) DEFAULT NULL,
  `nombres` varchar(45) DEFAULT NULL,
  `oficina` varchar(12) NOT NULL,
  `usuario` varchar(45) DEFAULT NULL,
  `pass` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

INSERT INTO `usuarios` VALUES (1, 'LOZA', 'TORRES', 'ALFREDO', '', '1', '1');

-- 
-- Filtros para las tablas descargadas (dump)
-- 

-- 
-- Filtros para la tabla `documentos`
-- 
ALTER TABLE `documentos`
  ADD CONSTRAINT `fk_idproyecto` FOREIGN KEY (`idproyecto`) REFERENCES `proyecto` (`idproyecto`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_idtipo` FOREIGN KEY (`idtipo`) REFERENCES `tipo` (`idtipo`);
